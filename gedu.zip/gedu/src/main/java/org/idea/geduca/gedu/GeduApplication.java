package org.idea.geduca.gedu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeduApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeduApplication.class, args);
	}
}
